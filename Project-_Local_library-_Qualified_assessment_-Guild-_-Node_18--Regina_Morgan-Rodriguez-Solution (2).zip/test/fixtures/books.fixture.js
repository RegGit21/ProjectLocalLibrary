module.exports = [
  {
    id: "5f447132c30e8abe6c988a8b",
    title: "veniam voluptate magna ipsum officia",
    genre: "Historical Fiction",
    authorId: 37,
    borrows: [
      {
        id: "5f446f2ea6b68cf6f85f6e28",
        returned: true,
      },
      {
        id: "5f446f2ead0070f44676f2f6",
        returned: true,
      },
    ],
  },
  {
    id: "5f447132d487bd81da01e25e",
    title: "sit eiusmod occaecat eu magna",
    genre: "Science",
    authorId: 8,
    borrows: [
      {
        id: "5f446f2e2cfa3e1d234679b9",
        returned: false,
      },
      {
        id: "5f446f2ed3609b719568a415",
        returned: true,
      },
      {
        id: "5f446f2e1c71888e2233621e",
        returned: true,
      },
      {
        id: "5f446f2e6059326d9feb9a68",
        returned: true,
      },
      {
        id: "5f446f2ede05a0b1e3394d8b",
        returned: true,
      },
      {
        id: "5f446f2e4081699cdc6a2735",
        returned: true,
      },
      {
        id: "5f446f2e3900dfec59489477",
        returned: true,
      },
      {
        id: "5f446f2e6059326d9feb9a68",
        returned: true,
      },
      {
        id: "5f446f2ec32d71dabec35b06",
        returned: true,
      },
      {
        id: "5f446f2ef2ab5f5a9f60c4f2",
        returned: true,
      },
      {
        id: "5f446f2e7a1be21e362b82f9",
        returned: true,
      },
    ],
  },
  {
    id: "5f4471329627160be1e8ce92",
    title: "esse ea veniam non occaecat",
    genre: "Classics",
    authorId: 10,
    borrows: [
      {
        id: "5f446f2ed3609b719568a415",
        returned: false,
      },
      {
        id: "5f446f2ec32d71dabec35b06",
        returned: true,
      },
      {
        id: "5f446f2ef2ab5f5a9f60c4f2",
        returned: true,
      },
      {
        id: "5f446f2e7a1be21e362b82f9",
        returned: true,
      },
    ],
  },
  {
    id: "5f44713265e5d8d17789beb0",
    title: "tempor occaecat fugiat",
    genre: "Travel",
    authorId: 16,
    borrows: [
      {
        id: "5f446f2e4eff1030e7316861",
        returned: true,
      },
      {
        id: "5f446f2ecc5c4787c403f844",
        returned: true,
      },
    ],
  },
  {
    id: "5f44713264bb872240dd62d0",
    title: "proident cupidatat fugiat aliquip do",
    genre: "Young Adult",
    authorId: 20,
    borrows: [
      {
        id: "5f446f2efa7fe184c4014dd2",
        returned: false,
      },
      {
        id: "5f446f2e59f9380a1d03d766",
        returned: true,
      },
    ],
  },
  {
    id: "5f447132a476ece080afa067",
    title: "ullamco est minim",
    genre: "Nonfiction",
    authorId: 25,
    borrows: [
      {
        id: "5f446f2e189628dfd4e6225e",
        returned: false,
      },
      {
        id: "5f446f2ec56b2fa77d5545ef",
        returned: true,
      },
      {
        id: "5f446f2e2f35653fa80bf490",
        returned: true,
      },
      {
        id: "5f446f2ee1661e64cde14e55",
        returned: true,
      },
      {
        id: "5f446f2ee5be00208a4481e0",
        returned: true,
      },
    ],
  },
  {
    id: "5f447132024bec2f2a94dedc",
    title: "ad incididunt magna",
    genre: "Classics",
    authorId: 38,
    borrows: [
      {
        id: "5f446f2eae901a82e0259947",
        returned: true,
      },
    ],
  },
  {
    id: "5f4471328ea4e12c67d5f691",
    title: "eiusmod pariatur Lorem ipsum consectetur",
    genre: "Science",
    authorId: 32,
    borrows: [
      {
        id: "5f446f2ec56b2fa77d5545ef",
        returned: false,
      },
      {
        id: "5f446f2e2f35653fa80bf490",
        returned: true,
      },
      {
        id: "5f446f2e637138095dcc3db2",
        returned: true,
      },
    ],
  },
  {
    id: "5f4471327864ee880caf5afc",
    title: "reprehenderit quis laboris adipisicing et",
    genre: "Science",
    authorId: 20,
    borrows: [
      {
        id: "5f446f2e2a4fcd687493a775",
        returned: false,
      },
      {
        id: "5f446f2ebe8314bcec531cc5",
        returned: true,
      },
    ],
  },
];
